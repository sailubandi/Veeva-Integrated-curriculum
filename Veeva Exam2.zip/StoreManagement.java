import java.util.*;

public class StoreManagement {

    static Map<String, Map<String, Integer>> storedb = new HashMap<>();
    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {

        int ch;

        do {
            System.out.println("\nMAIN MENU");
            System.out.println("1. Data");
            System.out.println("2. Queries");
            System.out.println("3. Exit");
            System.out.print("Enter choice: ");
            ch = sc.nextInt();
            sc.nextLine();

            switch (ch) {
                case 1:
                    dataoption();
                    break;
                case 2:
                    queryoption();
                    break;
                case 3:
                    System.out.println("Program Ended.");
                    break;
                default:
                    System.out.println("Invalid Choice!");
            }
        } while (ch != 3);
    }


    static void dataoption() {
        System.out.print("Enter Store ID: ");
        String sid = sc.nextLine();

        Map<String, Integer> pmap = new HashMap<>();
        System.out.print("Enter number of products: ");
        int n = sc.nextInt();
        sc.nextLine();

        for (int i = 0; i < n; i++) {
            System.out.print("Enter Product Name: ");
            String pn = sc.nextLine();
            System.out.print("Enter Price: ");
            int pr = sc.nextInt();
            sc.nextLine();
            pmap.put(pn, pr);
        }

        storedb.put(sid, pmap);
        System.out.println("Data Stored Successfully!");
    }


    static void queryoption() {
        int op;
        do {
            System.out.println("\n Menu ");
            System.out.println("1. Display products & prices of a store");
            System.out.println("2. Highest priced product of a store");
            System.out.println("3. Display stores containing a product");
            System.out.println("4. Back to Main Menu");
            System.out.print("Enter choice: ");
            op = sc.nextInt();
            sc.nextLine();

            switch (op) {
                case 1:
                    displayproducts();
                    break;
                case 2:
                    highestproduct();
                    break;
                case 3:
                    findstores();
                    break;
                case 4:
                    break;
                default:
                    System.out.println("Invalid Choice!");
            }
        } while (op != 4);
    }
    static void displayproducts() {
        System.out.print("Enter Store ID: ");
        String sid = sc.nextLine();

        if (storedb.containsKey(sid)) {
            for (Map.Entry<String, Integer> e : storedb.get(sid).entrySet()) {
                System.out.println(e.getKey() + " : " + e.getValue());
            }
        } else {
            System.out.println("Store not found!");
        }
    }

 
    static void highestproduct() {
        System.out.print("Enter Store ID: ");
        String sid = sc.nextLine();

        if (storedb.containsKey(sid)) {
            String hp = "";
            int max = 0;

            for (Map.Entry<String, Integer> e : storedb.get(sid).entrySet()) {
                if (e.getValue() > max) {
                    max = e.getValue();
                    hp = e.getKey();
                }
            }
            System.out.println("Highest priced product: " + hp + " = " + max);
        } else {
            System.out.println("Store not found!");
        }
    }

   
    static void findstores() {
        System.out.print("Enter Product Name: ");
        String pn = sc.nextLine();
        boolean f = false;

        for (Map.Entry<String, Map<String, Integer>> e : storedb.entrySet()) {
            if (e.getValue().containsKey(pn)) {
                System.out.println(e.getKey());
                f = true;
            }
        }

        if (!f) {
            System.out.println("Product not found in any store!");
        }
    }
}
