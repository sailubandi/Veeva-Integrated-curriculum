import java.util.*;

class Emp {
    String n, j, d;
    double s;

    Emp(String n, String j, double s, String d) {
        this.n = n;
        this.j = j;
        this.s = s;
        this.d = d;
    }

    void show() {
        System.out.println(n + "  " + j + "  " + s + "  " + d);
    }
}

public class EmployeeSort {

    static ArrayList<Emp> al = new ArrayList<>();
    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {

        int ch;
        do {
            System.out.println("\n MENU ");
            System.out.println("1. Add Employee");
            System.out.println("2. Sort Records");
            System.out.println("3. Display Employees");
            System.out.println("4. Exit");
            System.out.print("Enter choice: ");
            ch = sc.nextInt();
            sc.nextLine();

            switch (ch) {
                case 1:
                    add();
                    break;
                case 2:
                    sortmenu();
                    break;
                case 3:
                    display();
                    break;
                case 4:
                    System.out.println("Program Ended.");
                    break;
                default:
                    System.out.println("Invalid Choice!");
            }
        } while (ch != 4);
    }

    static void add() {
        System.out.print("Enter Name: ");
        String n = sc.nextLine();
        System.out.print("Enter Job: ");
        String j = sc.nextLine();
        System.out.print("Enter Salary: ");
        double s = sc.nextDouble();
        sc.nextLine();
        System.out.print("Enter Date of Joining (yyyy-mm-dd): ");
        String d = sc.nextLine();

        al.add(new Emp(n, j, s, d));
        System.out.println("Employee Added");
    }

    static void sortmenu() {
        int op;
        do {
            System.out.println("\n Menu");
            System.out.println("1. Salary Ascending");
            System.out.println("2. Salary Descending");
            System.out.println("3. Date Joining Ascending");
            System.out.println("4. Date Joining Descending");
            System.out.println("5. Back");
            System.out.print("Enter choice: ");
            op = sc.nextInt();
            sc.nextLine();

            switch (op) {
                case 1:
                    al.sort((a, b) -> Double.compare(a.s, b.s));
                    System.out.println("\nSorted by Salary Ascending");
                    display();
                    break;

                case 2:
                    al.sort((a, b) -> Double.compare(b.s, a.s));
                    System.out.println("\nSorted by Salary Descending");
                    display();
                    break;

                case 3:
                    al.sort((a, b) -> a.d.compareTo(b.d));
                    System.out.println("\nSorted by Date Joining Ascending");
                    display();
                    break;

                case 4:
                    al.sort((a, b) -> b.d.compareTo(a.d));
                    System.out.println("\nSorted by Date Joining Descending");
                    display();
                    break;

                case 5:
                    break;

                default:
                    System.out.println("Invalid Choice!");
            }
        } while (op != 5);
    }

    static void display() {
        if (al.isEmpty()) {
            System.out.println("No records found");
            return;
        }
        System.out.println("Name  Job  Salary  DateOfJoining");
        for (Emp e : al) {
            e.show();
        }
    }
}
